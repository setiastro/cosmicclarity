#feature-id CosmicClarity : SetiAstro > Cosmic Clarity
#feature-info This script works with Seti Astro Cosmic Clarity program to sharpen images

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/_//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Cosmic Clarity
 * Version: V2.1
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script works with Seti Astro Cosmic Clarity program to sharpen images
 *
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
 *
 * You are free to:
 * 1. Share — copy and redistribute the material in any medium or format
 * 2. Adapt — remix, transform, and build upon the material
 *
 * Under the following terms:
 * 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
 * 2. NonCommercial — You may not use the material for commercial purposes.
 *
 * @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
 *
 * COPYRIGHT © 2024 Franklin Marek. ALL RIGHTS RESERVED.
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/ColorSpace.jsh>

#define VERSION "v2.1"

// Determine platform and appropriate command/shell setup
let CMD_EXEC, SCRIPT_EXT;
if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS" || CoreApplication.platform == "LINUX") {
    CMD_EXEC = "/bin/sh";
    SCRIPT_EXT = ".sh";
} else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
    CMD_EXEC = "cmd.exe";
    SCRIPT_EXT = ".bat";
} else {
    console.criticalln("Unsupported platform: " + CoreApplication.platform);
}

// Define platform-agnostic folder paths
let pathSeparator = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") ? "\\" : "/";
let scriptTempDir = File.systemTempDirectory + pathSeparator + "SetiAstroCosmicClarity";
let setiAstroSharpConfigFile = scriptTempDir + pathSeparator + "setiastrocosmicclarity_config.csv";

// Ensure the temp directory exists
if (!File.directoryExists(scriptTempDir)) {
    File.createDirectory(scriptTempDir);
}

// Define global parameters
var SetiAstroSharpParameters = {
    targetView: undefined,
    isLinear: false,
    sharpeningMode: "Both",  // Default mode
    stellarAmount: 0.7,      // Default stellar sharpening amount
    nonStellarStrength: 4.0, // Default non-stellar feature size
    setiAstroSharpParentFolderPath: "",
    useGPU: true,

    configFilePath: setiAstroSharpConfigFile,

// Save current parameters to script instance
save: function() {
    Parameters.set("isLinear", this.isLinear);
    Parameters.set("useGPU", this.useGPU);  // Save the GPU acceleration state
    Parameters.set("setiAstroSharpParentFolderPath", this.setiAstroSharpParentFolderPath);
    Parameters.set("sharpeningMode", this.sharpeningMode);
    Parameters.set("stellarAmount", this.stellarAmount);
    Parameters.set("nonStellarStrength", this.nonStellarStrength);
    this.savePathToFile();
},

// Load saved parameters from script instance
load: function() {
    if (Parameters.has("isLinear"))
        this.isLinear = Parameters.getBoolean("isLinear");
    if (Parameters.has("useGPU"))
        this.useGPU = Parameters.getBoolean("useGPU");  // Load the GPU acceleration state
    if (Parameters.has("setiAstroSharpParentFolderPath"))
        this.setiAstroSharpParentFolderPath = Parameters.getString("setiAstroSharpParentFolderPath");
    if (Parameters.has("sharpeningMode"))
        this.sharpeningMode = Parameters.getString("sharpeningMode");
    if (Parameters.has("stellarAmount"))
        this.stellarAmount = Parameters.getReal("stellarAmount");
    if (Parameters.has("nonStellarStrength"))
        this.nonStellarStrength = Parameters.getReal("nonStellarStrength");
    this.loadPathFromFile();
},


    // Save the SetiAstroSharp parent folder path to a CSV file
    savePathToFile: function() {
        try {
            let file = new File;
            file.createForWriting(this.configFilePath);
            file.outTextLn(this.setiAstroSharpParentFolderPath);
            file.close();
        } catch (error) {
            console.warningln("Failed to save SetiAstroSharp parent folder path: " + error.message);
        }
    },

    // Load the SetiAstroSharp parent folder path from a CSV file
    loadPathFromFile: function() {
        try {
            if (File.exists(this.configFilePath)) {
                let file = new File;
                file.openForReading(this.configFilePath);
                let lines = File.readLines(this.configFilePath);
                if (lines.length > 0) {
                    this.setiAstroSharpParentFolderPath = lines[0].trim();
                }
                file.close();
            }
        } catch (error) {
            console.warningln("Failed to load SetiAstroSharp parent folder path: " + error.message);
        }
    }
};

// Main dialog for SetiAstroCosmicClarity
function SetiAstroSharpDialog() {
    this.__base__ = Dialog;
    this.__base__();

    console.hide();

    // Load saved parameters
    SetiAstroSharpParameters.load();

    // Title and description
    this.title = new Label(this);
    this.title.text = "SetiAstroCosmicClarity " + VERSION;
    this.title.textAlignment = TextAlign_Center;

    this.description = new TextBox(this);
    this.description.readOnly = true;
    this.description.text = "This script integrates with SetiAstroCosmicClarity for stellar and non-stellar sharpening.\n" +
                            "It saves the current image, runs the SetiAstroCosmicClarity tool, and replaces " +
                            "the image with the sharpened version.";
    this.description.setMinWidth(400);

    // Image Selection Dropdown
    this.imageSelectionLabel = new Label(this);
    this.imageSelectionLabel.text = "Select Image:";
    this.imageSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.imageSelectionDropdown = new ComboBox(this);
    this.imageSelectionDropdown.editEnabled = false;

    let windows = ImageWindow.windows;
    let activeWindowId = ImageWindow.activeWindow.mainView.id;
    for (let i = 0; i < windows.length; ++i) {
        this.imageSelectionDropdown.addItem(windows[i].mainView.id);
        if (windows[i].mainView.id === activeWindowId) {
            this.imageSelectionDropdown.currentItem = i; // Default to active image
        }
    }

    this.imageSelectionSizer = new HorizontalSizer;
    this.imageSelectionSizer.spacing = 4;
    this.imageSelectionSizer.add(this.imageSelectionLabel);
    this.imageSelectionSizer.add(this.imageSelectionDropdown, 100);

    // Radio buttons for mode selection
    this.sharpeningModeGroup = new RadioButton(this);
    this.sharpeningModeGroup.sizer = new HorizontalSizer;
    this.sharpeningModeGroup.sizer.spacing = 3;

    this.stellarRadioButton = new RadioButton(this);
    this.stellarRadioButton.text = "Stellar";
    this.stellarRadioButton.checked = SetiAstroSharpParameters.sharpeningMode === "Stellar Only";
    this.stellarRadioButton.onClick = () => this.updateVisibility();

    this.nonStellarRadioButton = new RadioButton(this);
    this.nonStellarRadioButton.text = "Non-Stellar";
    this.nonStellarRadioButton.checked = SetiAstroSharpParameters.sharpeningMode === "Non-Stellar Only";
    this.nonStellarRadioButton.onClick = () => this.updateVisibility();

    this.bothRadioButton = new RadioButton(this);
    this.bothRadioButton.text = "Both";
    this.bothRadioButton.checked = SetiAstroSharpParameters.sharpeningMode === "Both";
    this.bothRadioButton.onClick = () => this.updateVisibility();

    this.sharpeningModeGroup.sizer.add(this.stellarRadioButton);
    this.sharpeningModeGroup.sizer.add(this.nonStellarRadioButton);
    this.sharpeningModeGroup.sizer.add(this.bothRadioButton);

    // Stellar Amount slider
    this.stellarAmountSlider = new NumericControl(this);
    this.stellarAmountSlider.label.text = "Stellar Amount:";
    this.stellarAmountSlider.setRange(0, 1);
    this.stellarAmountSlider.setValue(SetiAstroSharpParameters.stellarAmount);
    this.stellarAmountSlider.setPrecision(2);
    this.stellarAmountSlider.onValueUpdated = function(value) {
        SetiAstroSharpParameters.stellarAmount = value;
    };

    // Non-Stellar Feature Size slider
    this.nonStellarStrengthSlider = new NumericControl(this);
    this.nonStellarStrengthSlider.label.text = "Non-Stellar Feature Size:";
    this.nonStellarStrengthSlider.setRange(1, 8);
    this.nonStellarStrengthSlider.setValue(SetiAstroSharpParameters.nonStellarStrength);
    this.nonStellarStrengthSlider.setPrecision(2);
    this.nonStellarStrengthSlider.onValueUpdated = function(value) {
        SetiAstroSharpParameters.nonStellarStrength = value;
    };

    // Linear state checkbox
    this.linearStateCheckbox = new CheckBox(this);
    this.linearStateCheckbox.text = "Image is in Linear State";
    this.linearStateCheckbox.checked = SetiAstroSharpParameters.isLinear;
    this.linearStateCheckbox.onCheck = function(checked) {
        SetiAstroSharpParameters.isLinear = checked;
        SetiAstroSharpParameters.save();
    };

    // Wrench Icon Button for setting the SetiAstroSharp parent folder path
    this.setupButton = new ToolButton(this);
    this.setupButton.icon = this.scaledResource(":/icons/wrench.png");
    this.setupButton.setScaledFixedSize(24, 24);
    this.setupButton.onClick = function() {
        let pathDialog = new GetDirectoryDialog;
        pathDialog.initialPath = SetiAstroSharpParameters.setiAstroSharpParentFolderPath;
        if (pathDialog.execute()) {
            SetiAstroSharpParameters.setiAstroSharpParentFolderPath = pathDialog.directory;
            SetiAstroSharpParameters.save();
        }
    };

// OK and Cancel buttons
this.okButton = new PushButton(this);
this.okButton.text = "OK";

// Modified onClick handler for OK button
this.okButton.onClick = () => {
    let messageBox = new MessageBox("Be Sure to Select 32-bit!!", "Reminder", StdIcon_Warning, StdButton_Ok);
    messageBox.execute();

    // Now proceed with the OK functionality after the user dismisses the message
    this.ok();
};


    this.cancelButton = new PushButton(this);
    this.cancelButton.text = "Cancel";
    this.cancelButton.onClick = () => this.cancel();

        // New Instance button
    this.newInstanceButton = new ToolButton(this);
    this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstanceButton.setScaledFixedSize(24, 24);
    this.newInstanceButton.toolTip = "Save a new instance of this script";
    this.newInstanceButton.onMousePress = function() {
    this.dialog.newInstance();
      }.bind(this);

        this.buttonsSizer = new HorizontalSizer;
    this.buttonsSizer.spacing = 6;
    this.buttonsSizer.add(this.newInstanceButton);
    this.buttonsSizer.addStretch();
    this.buttonsSizer.add(this.okButton);
    this.buttonsSizer.add(this.cancelButton);
    this.buttonsSizer.addStretch();

    // Layout
    this.sizer = new VerticalSizer;
    this.sizer.margin = 6;
    this.sizer.spacing = 6;
    this.sizer.addStretch();
    this.sizer.add(this.title);
    this.sizer.add(this.description);
    this.sizer.addStretch();
    this.sizer.add(this.imageSelectionSizer);
    this.sizer.spacing = 6;
    this.sizer.add(this.sharpeningModeGroup);
    this.sizer.spacing = 6;
    this.sizer.add(this.stellarAmountSlider);
    this.sizer.add(this.nonStellarStrengthSlider);
    this.sizer.add(this.linearStateCheckbox);
    this.sizer.addStretch();

// GPU Acceleration checkbox (only for Windows)
if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
    this.gpuAccelerationCheckbox = new CheckBox(this);
    this.gpuAccelerationCheckbox.text = "Enable GPU Acceleration";
    this.gpuAccelerationCheckbox.checked = true;  // Default to enabled
    this.gpuAccelerationCheckbox.onCheck = function(checked) {
        SetiAstroSharpParameters.enableGPU = checked;
    };

    this.sizer.add(this.gpuAccelerationCheckbox);
}

    this.sizer.add(this.setupButton);
    this.sizer.addSpacing(12);
    this.sizer.add(this.buttonsSizer);

    this.windowTitle = "SetiAstroCosmicClarity Script";
    this.adjustToContents();

    // Initially update visibility based on the selected mode
    this.updateVisibility();
}
SetiAstroSharpDialog.prototype = new Dialog;

// Update visibility of sliders based on sharpening mode
SetiAstroSharpDialog.prototype.updateVisibility = function() {
    let stellarMode = this.stellarRadioButton.checked;
    let nonStellarMode = this.nonStellarRadioButton.checked;
    let bothMode = this.bothRadioButton.checked;

    // Stellar Amount slider is visible for Stellar and Both modes
    this.stellarAmountSlider.visible = stellarMode || bothMode;
    // Non-Stellar slider is visible for Non-Stellar and Both modes
    this.nonStellarStrengthSlider.visible = nonStellarMode || bothMode;

    SetiAstroSharpParameters.sharpeningMode = stellarMode ? "Stellar Only" :
                                               nonStellarMode ? "Non-Stellar Only" : "Both";
};

// Function to create and save the temporary TIFF image with full unlinked stretch if needed
function saveImageAsTiff(inputFolderPath, view) {
    // Stretching before saving if the image is in a linear state
    if (SetiAstroSharpParameters.isLinear) {
        console.writeln("Image is in linear state, applying full unlinked stretch.");

        let imageMin = view.mainView.image.minimum();
        let imageMedian = view.mainView.image.median();
        SetiAstroSharpParameters.originalMin = imageMin;
        SetiAstroSharpParameters.originalMedian = imageMedian;
        let targetMedian = 0.25; // Target for the second stretch operation

        // First PixelMath operation: ($T-min($T))/(1-min($T))
        let pixelMath1 = new PixelMath;
        if (view.mainView.image.numberOfChannels === 1) {
            pixelMath1.expression = "$T-min($T)";
        } else {
            pixelMath1.expression = "MedColor=avg(med($T[0]),med($T[1]),med($T[2]));\n" +
                                    "MinColor=min(min($T[0]),min($T[1]),min($T[2]));\n" +
                                    "SDevColor=avg(sdev($T[0]),sdev($T[1]),sdev($T[2]));\n" +
                                    "BlackPoint = MinColor;\n" +
                                    "Rescaled = ($T - BlackPoint);";
            pixelMath1.symbols = "BlackPoint, Rescaled, MedColor, MinColor, SDevColor";
        }
        pixelMath1.useSingleExpression = true;
        pixelMath1.executeOn(view.mainView);

        // Second PixelMath operation: ((Med($T)-1)*0.25*$T)/(Med($T)*(0.25+$T-1)-0.25*$T)
        let pixelMath2 = new PixelMath;
        if (view.mainView.image.numberOfChannels === 1) {
            pixelMath2.expression = "((Med($T)-1)*" + targetMedian + "*$T)/(Med($T)*(0.25+$T-1)-0.25*$T)";
        } else {
            pixelMath2.expression = "MedianColor = avg(Med($T[0]),Med($T[1]),Med($T[2]));\n" +
                                    "((MedianColor-1)*" + targetMedian + "*$T)/(MedianColor*(" + targetMedian + "+$T-1)-" + targetMedian + "*$T)";
            pixelMath2.symbols = "MedianColor";
        }
        pixelMath2.useSingleExpression = true;
        pixelMath2.executeOn(view.mainView);
    }

    // Save the stretched image to the temporary folder
    let inputFilePath = inputFolderPath + pathSeparator + view.mainView.id + ".tiff";
    if (!view.saveAs(inputFilePath, true, false, false, false, "TIFF")) {
        throw new Error("Failed to save image as " + inputFilePath);
    }
    console.writeln("Image saved as TIFF: " + inputFilePath);
    console.writeln("Starting Sharpening, please watch the pop console for progress");
    console.flush();
    return inputFilePath;
}


function createBatchFile(batchFilePath, exePath, sharpeningMode, stellarAmount, nonStellarStrength, useGPU) {
    // Ensure that stellarAmount and nonStellarStrength are numbers
    stellarAmount = parseFloat(stellarAmount);
    nonStellarStrength = parseFloat(nonStellarStrength);

    console.writeln("Stellar Amount: " + stellarAmount);
    console.writeln("Non-Stellar Strength: " + nonStellarStrength);
    console.writeln("Sharpening Mode: " + sharpeningMode);
    console.writeln("Use GPU: " + (useGPU ? "Enabled" : "Disabled"));

    let batchContent;

    // Create platform-specific batch or shell content
    if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS") {
        // macOS/Linux shell script
        batchContent = "#!/bin/sh\n";
        batchContent += "cd \"" + exePath + "\"\n";
        batchContent += "./setiastrocosmicclaritymac " +
                        "--sharpening_mode \"" + sharpeningMode + "\" " +
                        "--stellar_amount " + stellarAmount.toFixed(2) + " " +
                        "--nonstellar_strength " + nonStellarStrength.toFixed(2) + " " +
                        (useGPU ? "" : "--disable_gpu") + "\n";  // Add disable_gpu flag if GPU is disabled
    } else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
        // Windows batch script
        batchContent = "@echo off\n";
        batchContent += "cd /d \"" + exePath + "\"\n";
        batchContent += "start setiastrocosmicclarity.exe " +
                        "--sharpening_mode \"" + sharpeningMode + "\" " +
                        "--stellar_amount " + stellarAmount.toFixed(2) + " " +
                        "--nonstellar_strength " + nonStellarStrength.toFixed(2) + " " +
                        (useGPU ? "" : "--disable_gpu") + "\n";  // Add disable_gpu flag if GPU is disabled
    } else {
        console.criticalln("Unsupported platform: " + CoreApplication.platform);
        return false;
    }

    // Write the script to the specified path
    try {
        File.writeTextFile(batchFilePath, batchContent);
        console.writeln((CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS") ? "Shell script created: " + batchFilePath : "Batch file created: " + batchFilePath);
    } catch (error) {
        console.criticalln("Failed to create batch/shell file: " + error.message);
        return false;
    }

    return true;
}



// Function to revert the image to its original linear state after sharpening
function revertToLinearState(view) {
    if (SetiAstroSharpParameters.isLinear) {
        console.writeln("Reverting to original linear state.");

        let originalMedian = SetiAstroSharpParameters.originalMedian;
        let originalMin = SetiAstroSharpParameters.originalMin;

        // First PixelMath operation to undo the unlinked stretch
        let pixelMath1 = new PixelMath;
        if (view.mainView.image.numberOfChannels === 1) {
            pixelMath1.expression = "((Med($T)-1)*" + originalMedian + "*$T)/(Med($T)*(" + originalMedian + "+$T-1)-" + originalMedian + "*$T)";
        } else {
            pixelMath1.expression = "MedColor = avg(Med($T[0]), Med($T[1]), Med($T[2]));\n" +
                                    "((MedColor-1)*" + originalMedian + "*$T)/(MedColor*(" + originalMedian + "+$T-1)-" + originalMedian + "*$T)";
            pixelMath1.symbols = "MedColor";
        }
        pixelMath1.useSingleExpression = true;
        pixelMath1.executeOn(view.mainView);

        console.writeln("Image reverted to original linear state.");
    }
}


// Function to retrieve the output image and revert stretch if necessary
function processOutputImage(outputFilePath, targetView, strength) {
    if (!File.exists(outputFilePath)) {
        console.criticalln("Sharpened file not found: " + outputFilePath);
        return;
    }

    let sharpenedWindow = ImageWindow.open(outputFilePath)[0];
    if (sharpenedWindow) {
        sharpenedWindow.show();

      // Now apply the PixelMath expression on the sharpened image, not the original one
      let pixelMath = new PixelMath;
      pixelMath.expression = "iif(" + sharpenedWindow.mainView.id + " == 0, $T, " + sharpenedWindow.mainView.id + ")";
      pixelMath.useSingleExpression = true;
      pixelMath.createNewImage = false;
      pixelMath.executeOn(targetView.mainView); // Apply on the target (original) image

        sharpenedWindow.forceClose();

        // Delete the sharpened file after loading
        try {
            File.remove(outputFilePath);
            console.writeln("Deleted sharpened file: " + outputFilePath);
        } catch (error) {
            console.warningln("Failed to delete sharpened file: " + outputFilePath);
        }

        // Revert to the original linear state if necessary
        revertToLinearState(targetView); // Reverting the original view to its linear state
    } else {
        console.criticalln("Failed to open sharpened image: " + outputFilePath);
    }
}



function msleep(milliseconds) {
    let start = Date.now();
    while (Date.now() - start < milliseconds) {
        // Busy wait for the specified number of milliseconds
    }
}

function waitForFile(outputFilePath, timeoutSeconds = 60) {
    let elapsedSeconds = 0;
    let pollingInterval = 1000;  // Check every 1 second (1000 ms)
    let timeoutMillis = timeoutSeconds * 1000;

    while (!File.exists(outputFilePath)) {
        if (elapsedSeconds >= timeoutMillis) {
            console.criticalln("Timeout waiting for file: " + outputFilePath);
            return false;
        }

        msleep(pollingInterval);
        elapsedSeconds += pollingInterval;
    }

    console.writeln("File found: " + outputFilePath);
    return true;
}

// Function to delete the input file
function deleteInputFile(inputFilePath) {
    try {
        if (File.exists(inputFilePath)) {
            File.remove(inputFilePath);
            console.writeln("Deleted input file: " + inputFilePath);
        } else {
            console.warningln("Input file not found: " + inputFilePath);
        }
    } catch (error) {
        console.warningln("Failed to delete input file: " + inputFilePath);
    }
}



// Dialog execution
let dialog = new SetiAstroSharpDialog();
                      console.show();
                        Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");

                    console.writeln("SetiAstroCosmicClarity process started.");
                    console.flush();
// Main execution block for running the script
if (dialog.execute()) {
    let selectedIndex = dialog.imageSelectionDropdown.currentItem;  // Fetch the selected index
    let selectedView = ImageWindow.windows[selectedIndex];  // Retrieve the selected image window

    if (!selectedView) {
        console.criticalln("Please select an image.");
    } else {
        let inputFolderPath = SetiAstroSharpParameters.setiAstroSharpParentFolderPath + pathSeparator + "input";
        let outputFolderPath = SetiAstroSharpParameters.setiAstroSharpParentFolderPath + pathSeparator + "output";
        let outputFileName = selectedView.mainView.id + "_sharpened.tif";
        let outputFilePath = outputFolderPath + pathSeparator + outputFileName;

        let inputFilePath = saveImageAsTiff(inputFolderPath, selectedView);

        let batchFilePath = SetiAstroSharpParameters.setiAstroSharpParentFolderPath + pathSeparator + "run_setiastrocosmicclarity" + SCRIPT_EXT;

      if (createBatchFile(batchFilePath, SetiAstroSharpParameters.setiAstroSharpParentFolderPath, SetiAstroSharpParameters.sharpeningMode, SetiAstroSharpParameters.stellarAmount, SetiAstroSharpParameters.nonStellarStrength, SetiAstroSharpParameters.useGPU)) {
          // Execute the batch file
          let process = new ExternalProcess;
          try {
              if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS" || CoreApplication.platform == "LINUX") {
                  if (!process.start(CMD_EXEC, [batchFilePath])) {
                      console.writeln("SetiAstroCosmicClarity started. Watch the console for updates.");
                      console.flush();
                  }
              } else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
                  if (!process.start(CMD_EXEC, ["/c", batchFilePath])) {
                      console.writeln("SetiAstroCosmicClarity started. Watch the console for updates.");
                      console.flush();
                  }
              }
          } catch (error) {
              console.criticalln("Error starting process: " + error.message);
          }

// Wait for the output file to be created with user confirmation to continue
let waiting = true;
while (waiting) {
    if (waitForFile(outputFilePath, 120)) {  // 120 seconds timeout
        processOutputImage(outputFilePath, selectedView, SetiAstroSharpParameters.stellarAmount);
        deleteInputFile(inputFilePath);
        waiting = false;  // File was found, exit the loop
    } else {
        // If the file was not found within the timeout, ask the user if they want to keep waiting
        let messageBox = new MessageBox(
            "The output file was not found after 120 seconds. Do you want to keep waiting?",
            "File Wait Timeout",
            StdIcon_Warning,
            StdButton_Yes,
            StdButton_No
        );

        // Show the message box and capture the user's response
        let userResponse = messageBox.execute();

        if (userResponse == StdButton_Yes) {
            console.writeln("User chose to continue waiting for the output file.");
            console.flush();
        } else {
            console.criticalln("User chose to stop waiting. Output file was not found.");
            waiting = false;  // Exit the loop and stop waiting
        }
    }
}
      }
    }
}
