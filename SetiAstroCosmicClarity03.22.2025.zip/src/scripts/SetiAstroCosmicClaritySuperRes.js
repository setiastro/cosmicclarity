#feature-id CosmicClarity : SetiAstro > Cosmic Clarity - Super Resolution
#feature-icon  cosmicclaritysuperres.svg
#feature-info This script works with Seti Astro Cosmic Clarity to perform image super resolution.

/******************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/\//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 * Cosmic Clarity - Super Resolution
 * Version: V1.0
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * Licensed under Creative Commons Attribution-NonCommercial 4.0 International License.
 ******************************************************************************/

#include <pjsr/Sizer.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/NumericControl.jsh>

#define VERSION "v1.0"

let pathSeparator = (CoreApplication.platform == "MSWINDOWS") ? "\\" : "/";
let scriptTempDir = File.systemTempDirectory + pathSeparator + "SetiAstroCosmicClaritySuperRes";
let configFilePath = scriptTempDir + pathSeparator + "superres_config.csv";
if (!File.directoryExists(scriptTempDir)) File.createDirectory(scriptTempDir);

var CCParameters = {
   targetView: undefined,
   scaleFactor: 2,
   parentFolder: "",
   useGPU: true,

   save: function() {
      Parameters.set("useGPU", this.useGPU);
      Parameters.set("parentFolder", this.parentFolder);
      Parameters.set("scaleFactor", this.scaleFactor);
      this.savePathToFile();
   },

   load: function() {
      if (Parameters.has("useGPU")) this.useGPU = Parameters.getBoolean("useGPU");
      if (Parameters.has("parentFolder")) this.parentFolder = Parameters.getString("parentFolder");
      if (Parameters.has("scaleFactor")) this.scaleFactor = Parameters.getInteger("scaleFactor");
      this.loadPathFromFile();
   },

   savePathToFile: function() {
      let file = new File;
      file.createForWriting(configFilePath);
      file.outTextLn(this.parentFolder);
      file.close();
   },

   loadPathFromFile: function() {
      if (File.exists(configFilePath)) {
         let lines = File.readLines(configFilePath);
         if (lines.length > 0)
            this.parentFolder = lines[0].trim();
      }
   }

};

CCParameters.load();

function CCSuperResDialog() {
   this.__base__ = Dialog;
   this.__base__();

   this.title = new Label(this);
   this.title.text = "Seti Astro Cosmic Clarity Super Resolution " + VERSION;
   this.title.textAlignment = TextAlign_Center;

   this.description = new Label(this);
   this.description.text = "Upscale images using Seti Astro Cosmic Clarity Super Resolution.";
   this.description.textAlignment = TextAlign_Center;

   this.imageDropdown = new ComboBox(this);
   ImageWindow.windows.forEach(w => this.imageDropdown.addItem(w.mainView.id));

   this.scaleFactorSlider = new NumericControl(this);
   this.scaleFactorSlider.label.text = "Upscale Factor:";
   this.scaleFactorSlider.setRange(2, 4);
   this.scaleFactorSlider.slider.setRange(2, 4);
   this.scaleFactorSlider.setValue(CCParameters.scaleFactor);
   this.scaleFactorSlider.setPrecision(0);
   this.scaleFactorSlider.onValueUpdated = value => CCParameters.scaleFactor = value;

   this.gpuCheckbox = new CheckBox(this);
   this.gpuCheckbox.text = "Enable GPU Acceleration";
   this.gpuCheckbox.checked = CCParameters.useGPU;
   this.gpuCheckbox.onCheck = checked => CCParameters.useGPU = checked;

   this.folderButton = new ToolButton(this);
   this.folderButton.icon = this.scaledResource(":/icons/wrench.png");
   this.folderButton.setScaledFixedSize(24, 24);
   this.folderButton.onClick = () => {
      let dlg = new GetDirectoryDialog();
      dlg.initialPath = CCParameters.parentFolder;
      if (dlg.execute()) {
         CCParameters.parentFolder = dlg.directory;
         CCParameters.save();
      }
   };

   this.okButton = new PushButton(this);
   this.okButton.text = "Run";
   this.okButton.onClick = () => this.ok();

   this.cancelButton = new PushButton(this);
   this.cancelButton.text = "Cancel";
   this.cancelButton.onClick = () => this.cancel();

   this.buttonSizer = new HorizontalSizer;
   this.buttonSizer.addStretch();
   this.buttonSizer.add(this.okButton);
   this.buttonSizer.add(this.cancelButton);
   this.buttonSizer.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.margin = 6;
   this.sizer.spacing = 4;
   this.sizer.add(this.title);
   this.sizer.add(this.description);
   this.sizer.add(this.imageDropdown);
   this.sizer.add(this.scaleFactorSlider);
   this.sizer.add(this.gpuCheckbox);
   this.sizer.add(this.folderButton);
   this.sizer.addSpacing(12);
   this.sizer.add(this.buttonSizer);

   this.windowTitle = "SetiAstroCosmicClarity SuperRes";
   this.adjustToContents();
}
CCSuperResDialog.prototype = new Dialog;

function runExternalSuperRes(imagePath, outputDir, scale, gpu) {
   var exePath = CCParameters.parentFolder + "/setiastrocosmicclarity_superres";
   if (CoreApplication.platform === "MSWINDOWS" || CoreApplication.platform === "Windows")
      exePath += ".exe";

   var args = [
      "--input", File.fullPath(imagePath),
      "--output_dir", File.fullPath(outputDir),
      "--scale", scale.toString(),
      "--model_dir", File.fullPath(CCParameters.parentFolder)
   ];

   if (!gpu)
      args.push("--disable_gpu");

   var process = new ExternalProcess;

   var progressPattern = /PROGRESS:\s*(\d+)%/;

   process.onStandardOutputDataAvailable = function() {
      var output = this.stdout.toString().trim();
      if (output.length > 0) {
         var progressMatch = output.match(progressPattern);
         if (progressMatch) {
            console.write("<end><clrbol>Super Resolution Progress: " + progressMatch[1] + "%");
         } else {
            console.writeln(output);
         }
      }
   };

   process.onStandardErrorDataAvailable = function() {
      var errorOutput = this.stderr.toString().trim();
      if (errorOutput.length > 0)
         console.criticalln(errorOutput);
   };

   process.onError = function(errorCode) {
      console.criticalln("Process error: " + errorCode);
   };

   process.onFinished = function(exitCode) {
      console.noteln("\nSuper Resolution processing finished with exit code: " + exitCode);
   };

   console.noteln("Executing command: " + exePath + " " + args.join(" "));

   process.start(exePath, args);

   while (process.isStarting)
      processEvents();
   while (process.isRunning)
      processEvents();
}

// Robust PixelMath handling to replace original image content
function processOutputImage(outputFilePath, targetView) {
   if (!File.exists(outputFilePath)) {
      console.criticalln("Output file not found: " + outputFilePath);
      return;
   }

   let superResWindow = ImageWindow.open(outputFilePath)[0];
   if (superResWindow) {
      superResWindow.show();

      //superResWindow.forceClose();

      try {
         File.remove(outputFilePath);
         console.writeln("Deleted temporary output file: " + outputFilePath);
      } catch (e) {
         console.warningln("Failed to delete output file: " + outputFilePath);
      }
   } else {
      console.criticalln("Failed to open super resolution output image.");
   }
}

// Corrected main() using above improvements
function main() {
   console.show()
    Console.criticalln("   ____    __  _   ___       __         \n  / __/__ / /_(_) / _ | ___ / /_______ ");
    Console.warningln(" _\\ \\/ -_) __/ / / __ |(_-</ __/ __/ _ \\ \n/___/\\__/\\__/_/ /_/ |_/__/\\__/_/  \\___/ \n                                         ");
   let dialog = new CCSuperResDialog();
   if (dialog.execute()) {
      CCParameters.save();

      if (CCParameters.parentFolder.trim() === "") {
         new MessageBox(
            "Please use the wrench icon to set the Cosmic Clarity parent folder path before running.",
            "Folder Path Not Set",
            StdIcon_Warning
         ).execute();
         return;
      }

      let selectedView = ImageWindow.windows[dialog.imageDropdown.currentItem];
      if (!selectedView) throw new Error("No image selected.");

      let inputDir = CCParameters.parentFolder + "/input";
      let outputDir = CCParameters.parentFolder + "/output";
      if (!File.directoryExists(inputDir)) File.createDirectory(inputDir);
      if (!File.directoryExists(outputDir)) File.createDirectory(outputDir);

      let inputPath = inputDir + "/" + selectedView.mainView.id + ".fit";
      selectedView.saveAs(inputPath, false, false, false, false);

      runExternalSuperRes(inputPath, outputDir, CCParameters.scaleFactor, CCParameters.useGPU);

      let outputPath = outputDir + "/" + selectedView.mainView.id + "_upscaled" + CCParameters.scaleFactor + "x.tif";
      while (!File.exists(outputPath)) { msleep(1000); processEvents(); }
      msleep(2000); // Wait additional time to ensure write is complete

      // Use the robust PixelMath processing function
      processOutputImage(outputPath, selectedView);

      // Clean up the input file as well
      try {
         File.remove(inputPath);
         console.writeln("Deleted input file: " + inputPath);
      } catch (e) {
         console.warningln("Failed to delete input file: " + inputPath);
      }

      console.writeln("Super Resolution completed successfully.");
   } else {
      console.writeln("Cancelled by user.");
   }
}

main();

