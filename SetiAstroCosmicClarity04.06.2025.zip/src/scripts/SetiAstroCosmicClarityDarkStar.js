#feature-id CosmicClarity : SetiAstro > Cosmic Clarity - Dark Star
#feature-icon  cosmicclaritydarkstar.svg
#feature-info This script integrates with the Seti Astro Cosmic Clarity Dark Star program to remove stars from images.

/****************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/\//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Cosmic Clarity - Dark Star
 * Version: v1.0
 * Author: Franklin Marek / Your Name
 * Website: www.setiastro.com
 *
 * This script works with the Seti Astro Cosmic Clarity Dark Star program to remove stars
 * from images. It passes three arguments:
 *    --disable_gpu         Disable GPU acceleration (if unchecked, GPU is enabled)
 *    --star_removal_mode   Either "additive" or "unscreen" (default is "unscreen")
 *    --show_extracted_stars  When selected, imports an additional output image containing only the extracted stars.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/ColorSpace.jsh>

// Determine platform and appropriate command/shell setup
let CMD_EXEC, SCRIPT_EXT;
if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS") {
    CMD_EXEC = "/bin/sh";
    SCRIPT_EXT = ".sh";
} else if (CoreApplication.platform == "Linux") {
    CMD_EXEC = "/bin/sh";
    SCRIPT_EXT = ".sh";
} else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
    CMD_EXEC = "cmd.exe";
    SCRIPT_EXT = ".bat";
} else {
    console.criticalln("Unsupported platform: " + CoreApplication.platform);
}

// Define platform-agnostic folder paths
let pathSeparator = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") ? "\\" : "/";
let scriptTempDir = File.systemTempDirectory + pathSeparator + "SetiAstroCosmicClarityDarkStar";
let setiAstroDarkStarConfigFile = scriptTempDir + pathSeparator + "setiastrocosmicclaritydarkstar_config.csv";

// Ensure the temp directory exists
if (!File.directoryExists(scriptTempDir)) {
    File.createDirectory(scriptTempDir);
}

// Global parameters for Dark Star
var SetiAstroDarkStarParameters = {
    targetView: undefined,
    // Star removal mode: choices are 'additive' or 'unscreen'
    starRemovalMode: "unscreen",
    // True means GPU acceleration is enabled (if false, we add --disable_gpu)
    useGPU: true,
    // If true, the script will import an additional output image with only the extracted stars.
    showExtractedStars: false,
    setiAstroDarkStarParentFolderPath: "",

    save: function() {
        Parameters.set("useGPU", this.useGPU);
        Parameters.set("setiAstroDarkStarParentFolderPath", this.setiAstroDarkStarParentFolderPath);
        Parameters.set("starRemovalMode", this.starRemovalMode);
        Parameters.set("showExtractedStars", this.showExtractedStars);
        this.savePathToFile();
    },

    load: function() {
        if (Parameters.has("useGPU"))
            this.useGPU = Parameters.getBoolean("useGPU");
        if (Parameters.has("setiAstroDarkStarParentFolderPath"))
            this.setiAstroDarkStarParentFolderPath = Parameters.getString("setiAstroDarkStarParentFolderPath");
        if (Parameters.has("starRemovalMode"))
            this.starRemovalMode = Parameters.getString("starRemovalMode");
        if (Parameters.has("showExtractedStars"))
            this.showExtractedStars = Parameters.getBoolean("showExtractedStars");
        this.loadPathFromFile();
    },

    savePathToFile: function() {
        try {
            let file = new File;
            file.createForWriting(setiAstroDarkStarConfigFile);
            file.outTextLn(this.setiAstroDarkStarParentFolderPath);
            file.close();
        } catch (error) {
            console.warningln("Failed to save Dark Star parent folder path: " + error.message);
        }
    },

    loadPathFromFile: function() {
        try {
            if (File.exists(setiAstroDarkStarConfigFile)) {
                let file = new File;
                file.openForReading(setiAstroDarkStarConfigFile);
                let lines = File.readLines(setiAstroDarkStarConfigFile);
                if (lines.length > 0) {
                    this.setiAstroDarkStarParentFolderPath = lines[0].trim();
                }
                file.close();
            }
        } catch (error) {
            console.warningln("Failed to load Dark Star parent folder path: " + error.message);
        }
    }
};

// Dialog setup for Dark Star
function SetiAstroDarkStarDialog() {
    this.__base__ = Dialog;
    this.__base__();

    console.hide();
    SetiAstroDarkStarParameters.load();

    this.title = new Label(this);
    this.title.text = "SetiAstroCosmicClarityDarkStar v1.0";
    this.title.textAlignment = TextAlign_Center;

    this.description = new TextBox(this);
    this.description.readOnly = true;
    this.description.text = "This script integrates with the Seti Astro Cosmic Clarity Dark Star program to remove stars from images.\n" +
                            "It saves the current image, runs Dark Star with the selected options, and then replaces the image " +
                            "with the starless output. Optionally, an additional image with only the extracted stars is imported.";
    this.description.setMinWidth(400);

    // Image selection dropdown (same as in Denoise)
    this.imageSelectionLabel = new Label(this);
    this.imageSelectionLabel.text = "Select Image:";
    this.imageSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.imageSelectionDropdown = new ComboBox(this);
    this.imageSelectionDropdown.editEnabled = false;

    let windows = ImageWindow.windows;
    let activeWindowId = ImageWindow.activeWindow.mainView.id;
    for (let i = 0; i < windows.length; ++i) {
        this.imageSelectionDropdown.addItem(windows[i].mainView.id);
        if (windows[i].mainView.id === activeWindowId) {
            this.imageSelectionDropdown.currentItem = i;
        }
    }

    this.imageSelectionSizer = new HorizontalSizer;
    this.imageSelectionSizer.spacing = 4;
    this.imageSelectionSizer.add(this.imageSelectionLabel);
    this.imageSelectionSizer.add(this.imageSelectionDropdown, 100);

    // Combo box for Star Removal Mode
    this.starRemovalModeLabel = new Label(this);
    this.starRemovalModeLabel.text = "Star Removal Mode:";
    this.starRemovalModeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.starRemovalModeCombo = new ComboBox(this);
    this.starRemovalModeCombo.addItem("unscreen");
    this.starRemovalModeCombo.addItem("additive");
    // Set default selection
    if (SetiAstroDarkStarParameters.starRemovalMode === "additive")
        this.starRemovalModeCombo.currentItem = 1;
    else
        this.starRemovalModeCombo.currentItem = 0;
    this.starRemovalModeCombo.onItemSelected = function(index) {
        let mode = this.itemText(index);
        SetiAstroDarkStarParameters.starRemovalMode = mode;
    };

    this.starRemovalModeSizer = new HorizontalSizer;
    this.starRemovalModeSizer.spacing = 4;
    this.starRemovalModeSizer.add(this.starRemovalModeLabel);
    this.starRemovalModeSizer.add(this.starRemovalModeCombo, 100);

    // GPU Acceleration checkbox
    this.gpuAccelerationCheckbox = new CheckBox(this);
    this.gpuAccelerationCheckbox.text = "Enable GPU Acceleration";
    this.gpuAccelerationCheckbox.checked = SetiAstroDarkStarParameters.useGPU;
    this.gpuAccelerationCheckbox.onCheck = function(checked) {
        SetiAstroDarkStarParameters.useGPU = checked;
    };

    // Show Extracted Stars checkbox
    this.showExtractedStarsCheckbox = new CheckBox(this);
    this.showExtractedStarsCheckbox.text = "Show Extracted Stars";
    this.showExtractedStarsCheckbox.checked = SetiAstroDarkStarParameters.showExtractedStars;
    this.showExtractedStarsCheckbox.onCheck = function(checked) {
        SetiAstroDarkStarParameters.showExtractedStars = checked;
    };

    // Button for setting Dark Star parent folder path
    this.setupButton = new ToolButton(this);
    this.setupButton.icon = this.scaledResource(":/icons/wrench.png");
    this.setupButton.setScaledFixedSize(24, 24);
    this.setupButton.onClick = function() {
        let pathDialog = new GetDirectoryDialog;
        pathDialog.initialPath = SetiAstroDarkStarParameters.setiAstroDarkStarParentFolderPath;
        if (pathDialog.execute()) {
            SetiAstroDarkStarParameters.setiAstroDarkStarParentFolderPath = pathDialog.directory;
            SetiAstroDarkStarParameters.save();
        }
    };

    // OK and Cancel buttons
    this.okButton = new PushButton(this);
    this.okButton.text = "OK";
    this.okButton.onClick = () => this.ok();

    this.cancelButton = new PushButton(this);
    this.cancelButton.text = "Cancel";
    this.cancelButton.onClick = () => this.cancel();

    // New Instance button
    this.newInstanceButton = new ToolButton(this);
    this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstanceButton.setScaledFixedSize(24, 24);
    this.newInstanceButton.toolTip = "Save a new instance of this script";
    this.newInstanceButton.onMousePress = function() {
        this.dialog.newInstance();
    }.bind(this);

    this.buttonsSizer = new HorizontalSizer;
    this.buttonsSizer.spacing = 6;
    this.buttonsSizer.add(this.newInstanceButton);
    this.buttonsSizer.addStretch();
    this.buttonsSizer.add(this.okButton);
    this.buttonsSizer.add(this.cancelButton);
    this.buttonsSizer.addStretch();

    // Layout the dialog
    this.sizer = new VerticalSizer;
    this.sizer.margin = 6;
    this.sizer.spacing = 6;
    this.sizer.addStretch();
    this.sizer.add(this.title);
    this.sizer.add(this.description);
    this.sizer.addStretch();
    this.sizer.add(this.imageSelectionSizer);
    this.sizer.add(this.starRemovalModeSizer);
    this.sizer.add(this.gpuAccelerationCheckbox);
    this.sizer.add(this.showExtractedStarsCheckbox);
    this.sizer.add(this.setupButton);
    this.sizer.addSpacing(12);
    this.sizer.add(this.buttonsSizer);

    this.windowTitle = "SetiAstroCosmicClarity Script";
    this.adjustToContents();
}
SetiAstroDarkStarDialog.prototype = new Dialog;

// Save the current image as a 32-bit XISF file
function saveImageAsTiff(inputFolderPath, view) {
    let imgWindow = view.isMainView ? view.window : view.mainView.window;
    if (!imgWindow) {
        throw new Error("Image window is undefined for the specified view.");
    }
    let fileName = imgWindow.mainView.id;
    let filePath = inputFolderPath + pathSeparator + fileName + ".xisf";
    if (!imgWindow.saveAs(filePath, false, false, false, false)) {
        throw new Error("Failed to save image as 32-bit XISF: " + filePath);
    }
    console.writeln("Image saved as 32-bit XISF: " + filePath);
    return filePath;
}

// Create the command line for Dark Star
function createDarkStarCmd(exePath, useGPU, starRemovalMode, showExtractedStars) {
    let cmdLine = "";
    if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
        let exeFullPath = exePath + "/" + "setiastrocosmicclarity_darkstar.exe";
        cmdLine =
            "\"" + exeFullPath + "\" " +
            "--star_removal_mode " + starRemovalMode + " " +
            (useGPU ? "" : "--disable_gpu") + " " +
            (showExtractedStars ? "--show_extracted_stars" : "");
    }
    else if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS") {
        let exeFullPath = exePath + "/" + "setiastrocosmicclarity_darkstar";
        cmdLine =
            "\"" + exeFullPath + "\" " +
            "--star_removal_mode " + starRemovalMode + " " +
            (useGPU ? "" : "--disable_gpu") + " " +
            (showExtractedStars ? "--show_extracted_stars" : "");
    }
    else if (CoreApplication.platform == "Linux") {
        let exeFullPath = exePath + "/" + "setiastrocosmicclarity_darkstar";
        cmdLine =
            "\"" + exeFullPath + "\" " +
            "--star_removal_mode " + starRemovalMode + " " +
            (useGPU ? "" : "--disable_gpu") + " " +
            (showExtractedStars ? "--show_extracted_stars" : "");
    }
    else {
        console.criticalln("Unsupported platform: " + CoreApplication.platform);
        return false;
    }
    return cmdLine;
}

// Wait for the output file to appear
function waitForFile(outputFilePath) {
    let pollingInterval = 1000;
    let postFindDelay = 2000;
    while (!File.exists(outputFilePath)) {
        msleep(pollingInterval);
    }
    console.writeln("Output file found: " + outputFilePath);
    console.writeln("Waiting for " + (postFindDelay / 1000) + " seconds to ensure complete saving.");
    msleep(postFindDelay);
    return true;
}

// Process the starless output image and replace the target view using PixelMath
function processDarkStarOutputImage(outputFilePath, targetView) {
    if (!File.exists(outputFilePath)) {
        console.criticalln("Starless file not found: " + outputFilePath);
        return;
    }
    let starlessWindow = ImageWindow.open(outputFilePath)[0];
    if (starlessWindow) {
        starlessWindow.show();
        let pixelMath = new PixelMath;
        pixelMath.expression = "iif(" + starlessWindow.mainView.id + " == 0, $T, " + starlessWindow.mainView.id + ")";
        pixelMath.useSingleExpression = true;
        pixelMath.createNewImage = false;
        pixelMath.executeOn(targetView.mainView);
        starlessWindow.forceClose();
        try {
            File.remove(outputFilePath);
            console.writeln("Deleted starless file: " + outputFilePath);
        } catch (error) {
            console.warningln("Failed to delete starless file: " + outputFilePath);
        }
    } else {
        console.criticalln("Failed to open starless image: " + outputFilePath);
    }
}

// Process the extracted stars image by opening it
function processExtractedStarsImage(outputFilePath) {
    if (!File.exists(outputFilePath)) {
        console.warningln("Stars-only file not found: " + outputFilePath);
        return;
    }
    let starsWindow = ImageWindow.open(outputFilePath)[0];
    if (starsWindow) {
        starsWindow.show();
        console.writeln("Extracted stars image opened: " + outputFilePath);
    } else {
        console.criticalln("Failed to open stars-only image: " + outputFilePath);
    }
}

// Delete the temporary input file
function deleteInputFile(inputFilePath) {
    try {
        if (File.exists(inputFilePath)) {
            File.remove(inputFilePath);
            console.writeln("Deleted input file: " + inputFilePath);
        } else {
            console.warningln("Input file not found: " + inputFilePath);
        }
    } catch (error) {
        console.warningln("Failed to delete input file: " + inputFilePath);
    }
}

// Main execution block
let dialog = new SetiAstroDarkStarDialog();
console.show();
console.writeln("SetiAstroCosmicClarityDarkStar process started.");
console.flush();

if (dialog.execute()) {
    let selectedIndex = dialog.imageSelectionDropdown.currentItem;
    let selectedView = ImageWindow.windows[selectedIndex];

    if (!selectedView) {
        console.criticalln("Please select an image.");
    } else {
        let inputFolderPath = SetiAstroDarkStarParameters.setiAstroDarkStarParentFolderPath + pathSeparator + "input";
        let outputFolderPath = SetiAstroDarkStarParameters.setiAstroDarkStarParentFolderPath + pathSeparator + "output";
        let baseName = selectedView.mainView.id;

        // Define output filenames
        let starlessOutputFileName = baseName + "_starless.xisf";
        let starlessOutputFilePath = outputFolderPath + pathSeparator + starlessOutputFileName;
        let starsOnlyOutputFileName = baseName + "_stars_only.xisf";
        let starsOnlyOutputFilePath = outputFolderPath + pathSeparator + starsOnlyOutputFileName;

        let inputFilePath = saveImageAsTiff(inputFolderPath, selectedView);
        let cmdLine = createDarkStarCmd(
            SetiAstroDarkStarParameters.setiAstroDarkStarParentFolderPath,
            SetiAstroDarkStarParameters.useGPU,
            SetiAstroDarkStarParameters.starRemovalMode,
            SetiAstroDarkStarParameters.showExtractedStars
        );

        let process = new ExternalProcess;
        let p = false;

// Global variable to hold the last progress message.
        let message = "Progress:   0% Chunks:   0/  0";

let lastProgress = "";

process.onStandardOutputDataAvailable = function() {
    var output = String(this.stdout);
    if (output.contains("processed")) {
        output = "INFO -> " + output.trim();
    }
    // Match Dark Star’s progress output: "Progress: 100.00% (135/135 chunks processed)"
    let match = output.match(/Progress:\s*([\d.]+)%\s*\((\d+)\/(\d+)/);
    if (match) {
        let percentage = parseFloat(match[1]);
        let processedChunks = parseInt(match[2], 10);
        let totalChunks = parseInt(match[3], 10);
        // Create the new progress string using a fixed format.
        let newProgress = format("Progress: %6.2f%% (%4d/%4d chunks processed)", percentage, processedChunks, totalChunks);

        // Create a string of backspaces equal to the length of the last progress string.
        let backspaces = "";
        for (let i = 0; i < lastProgress.length; i++) {
            backspaces += "\b";
        }
        // Write the backspaces followed by the new progress string.
        Console.write(backspaces + newProgress);
        // Update the last progress string.
        lastProgress = newProgress;
    } else {
        // For any non-progress output, simply flush any pending progress update.
        if (lastProgress.length > 0) {
            Console.writeln(""); // End the progress line.
            lastProgress = "";
        }
        Console.writeln(output);
    }
};






        process.onStandardErrorDataAvailable = function() {
            Console.criticalln('Error: ' + this.stderr.toString());
        };
        process.onStarted = function() {
            Console.noteln("starting Dark Star..." + CMD_EXEC + " " + cmdLine);
        };
        process.onError = function(code) {
            Console.criticalln(' ERROR: ' + code);
        };
        process.onFinished = function() {
            Console.noteln('Dark Star finished...');
        };

        try {
            // Tokenize the command line preserving quoted substrings
            let tokens = cmdLine.match(/"[^"]+"|\S+/g);
            if (!tokens || tokens.length < 1) {
                console.criticalln("Could not parse command line: " + cmdLine);
                throw new Error("No tokens found");
            }
            let exePath = tokens[0].replace(/^"(.*)"$/, "$1");
            let args = [];
            for (let i = 1; i < tokens.length; i++) {
                args.push(tokens[i].replace(/^"(.*)"$/, "$1"));
            }
            if (!process.start(exePath, args)) {
                console.noteln("SetiAstroCosmicClarityDarkStar starting...");
                console.flush();
            }
            for (; process.isStarting; )
                processEvents();
            for (; process.isRunning; )
                processEvents();
        } catch (error) {
            console.criticalln("Error starting process: " + error.message);
        }

        // Wait for the starless output file and process it
        if (waitForFile(starlessOutputFilePath)) {
            processDarkStarOutputImage(starlessOutputFilePath, selectedView);
        } else {
            console.criticalln("Starless output file not found within timeout.");
        }

        // If the user requested to show extracted stars, wait for and open that file too
        if (SetiAstroDarkStarParameters.showExtractedStars) {
            if (waitForFile(starsOnlyOutputFilePath)) {
                processExtractedStarsImage(starsOnlyOutputFilePath);
            } else {
                console.criticalln("Stars-only output file not found within timeout.");
            }
        }
        deleteInputFile(inputFilePath);
    }
}
