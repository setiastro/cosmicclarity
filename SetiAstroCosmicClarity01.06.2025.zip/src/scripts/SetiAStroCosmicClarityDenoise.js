#feature-id CosmicClarity : SetiAstro > Cosmic Clarity - Denoise
#feature-icon  cosmicclaritydenoise.svg
#feature-info This script works with Seti Astro Cosmic Clarity program to denoise images

/****************************************************************************
 *######################################################################
 *#        ___     __      ___       __                                #
 *#       / __/___/ /__   / _ | ___ / /________                        #
 *#      _\ \/ -_) _ _   / __ |(_-</ __/ __/ _ \                       #
 *#     /___/\__/\//_/  /_/ |_/___/\__/_/  \___/                       #
 *#                                                                    #
 *######################################################################
 *
 * Cosmic Clarity - Denoise
 * Version: V1.5
 * Author: Franklin Marek
 * Website: www.setiastro.com
 *
 * This script works with Seti Astro Cosmic Clarity Denoise program to reduce noise in images.
 *
 * This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
 ******************************************************************************/

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/FileMode.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/ColorSpace.jsh>

#define VERSION "v1.5"

// Determine platform and appropriate command/shell setup
let CMD_EXEC, SCRIPT_EXT;
if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS") {
    CMD_EXEC = "/bin/sh";
    SCRIPT_EXT = ".sh";
} else if (CoreApplication.platform == "Linux") {  // Correct platform string for Linux
    CMD_EXEC = "/bin/sh";
    SCRIPT_EXT = ".sh";
} else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
    CMD_EXEC = "cmd.exe";
    SCRIPT_EXT = ".bat";
} else {
    console.criticalln("Unsupported platform: " + CoreApplication.platform);
}


// Define platform-agnostic folder paths
let pathSeparator = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") ? "\\" : "/";
let scriptTempDir = File.systemTempDirectory + pathSeparator + "SetiAstroCosmicClarityDenoise";
let setiAstroDenoiseConfigFile = scriptTempDir + pathSeparator + "setiastrocosmicclaritydenoise_config.csv";

// Ensure the temp directory exists
if (!File.directoryExists(scriptTempDir)) {
    File.createDirectory(scriptTempDir);
}

// Define global parameters
var SetiAstroDenoiseParameters = {
    targetView: undefined,
    denoiseStrength: 0.9,  // Default denoise strength
    setiAstroDenoiseParentFolderPath: "",
    useGPU: true,
    denoiseMode: "full",  // Default mode set to 'luminance'

    save: function() {
        Parameters.set("useGPU", this.useGPU);
        Parameters.set("setiAstroDenoiseParentFolderPath", this.setiAstroDenoiseParentFolderPath);
        Parameters.set("denoiseStrength", this.denoiseStrength);
        Parameters.set("denoiseMode", this.denoiseMode);  // Save denoiseMode
        this.savePathToFile();
    },

    load: function() {
        if (Parameters.has("useGPU"))
            this.useGPU = Parameters.getBoolean("useGPU");
        if (Parameters.has("setiAstroDenoiseParentFolderPath"))
            this.setiAstroDenoiseParentFolderPath = Parameters.getString("setiAstroDenoiseParentFolderPath");
        if (Parameters.has("denoiseStrength"))
            this.denoiseStrength = Parameters.getReal("denoiseStrength");
        if (Parameters.has("denoiseMode"))
            this.denoiseMode = Parameters.getString("denoiseMode");  // Load denoiseMode
        this.loadPathFromFile();
    },
    savePathToFile: function() {
        try {
            let file = new File;
            file.createForWriting(setiAstroDenoiseConfigFile);
            file.outTextLn(this.setiAstroDenoiseParentFolderPath);
            file.close();
        } catch (error) {
            console.warningln("Failed to save SetiAstroDenoise parent folder path: " + error.message);
        }
    },

    loadPathFromFile: function() {
        try {
            if (File.exists(setiAstroDenoiseConfigFile)) {
                let file = new File;
                file.openForReading(setiAstroDenoiseConfigFile);
                let lines = File.readLines(setiAstroDenoiseConfigFile);
                if (lines.length > 0) {
                    this.setiAstroDenoiseParentFolderPath = lines[0].trim();
                }
                file.close();
            }
        } catch (error) {
            console.warningln("Failed to load SetiAstroDenoise parent folder path: " + error.message);
        }
    }
};

// Dialog setup, image selection, denoise strength slider, etc.
function SetiAstroDenoiseDialog() {
    this.__base__ = Dialog;
    this.__base__();

    console.hide();
    SetiAstroDenoiseParameters.load();

    this.title = new Label(this);
    this.title.text = "SetiAstroCosmicClarityDenoise " + VERSION;
    this.title.textAlignment = TextAlign_Center;

    this.description = new TextBox(this);
    this.description.readOnly = true;
    this.description.text = "This script integrates with SetiAstroCosmicClarityDenoise for noise reduction.\n" +
                            "It saves the current image, runs the SetiAstroCosmicClarityDenoise tool, and replaces " +
                            "the image with the denoised version.";
    this.description.setMinWidth(400);

    this.imageSelectionLabel = new Label(this);
    this.imageSelectionLabel.text = "Select Image:";
    this.imageSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

    this.imageSelectionDropdown = new ComboBox(this);
    this.imageSelectionDropdown.editEnabled = false;

    let windows = ImageWindow.windows;
    let activeWindowId = ImageWindow.activeWindow.mainView.id;
    for (let i = 0; i < windows.length; ++i) {
        this.imageSelectionDropdown.addItem(windows[i].mainView.id);
        if (windows[i].mainView.id === activeWindowId) {
            this.imageSelectionDropdown.currentItem = i;
        }
    }

    this.imageSelectionSizer = new HorizontalSizer;
    this.imageSelectionSizer.spacing = 4;
    this.imageSelectionSizer.add(this.imageSelectionLabel);
    this.imageSelectionSizer.add(this.imageSelectionDropdown, 100);

// Denoise Strength slider
this.denoiseStrengthSlider = new NumericControl(this);
this.denoiseStrengthSlider.label.text = "Noise Reduction Strength:";
this.denoiseStrengthSlider.setRange(0, 1);  // Updated range between 0 and 1
this.denoiseStrengthSlider.setValue(SetiAstroDenoiseParameters.denoiseStrength);
this.denoiseStrengthSlider.setPrecision(2);  // Keeping 2 decimal places for precision
this.denoiseStrengthSlider.onValueUpdated = function(value) {
    SetiAstroDenoiseParameters.denoiseStrength = value;
};

// Radio buttons for denoise mode
this.fullDenoiseRadio = new RadioButton(this);
this.fullDenoiseRadio.text = "Full Denoise";
this.fullDenoiseRadio.checked = SetiAstroDenoiseParameters.denoiseMode === "full";  // Fixed this to properly check the mode
this.fullDenoiseRadio.onCheck = function(checked) {
    if (checked) {
        SetiAstroDenoiseParameters.denoiseMode = "full";  // Set mode to 'full' when Full Denoise is selected
    }
};

this.luminanceDenoiseRadio = new RadioButton(this);
this.luminanceDenoiseRadio.text = "Luminance Only";
this.luminanceDenoiseRadio.checked = SetiAstroDenoiseParameters.denoiseMode === "luminance";  // Fixed this as well
this.luminanceDenoiseRadio.onCheck = function(checked) {
    if (checked) {
        SetiAstroDenoiseParameters.denoiseMode = "luminance";  // Set mode to 'luminance' when Luminance Only is selected
    }
};


    this.denoiseModeSizer = new HorizontalSizer;
    this.denoiseModeSizer.spacing = 4;
    this.denoiseModeSizer.add(this.fullDenoiseRadio);
    this.denoiseModeSizer.add(this.luminanceDenoiseRadio);


    // Wrench Icon Button for setting the SetiAstroDenoise parent folder path
    this.setupButton = new ToolButton(this);
    this.setupButton.icon = this.scaledResource(":/icons/wrench.png");
    this.setupButton.setScaledFixedSize(24, 24);
    this.setupButton.onClick = function() {
        let pathDialog = new GetDirectoryDialog;
        pathDialog.initialPath = SetiAstroDenoiseParameters.setiAstroDenoiseParentFolderPath;
        if (pathDialog.execute()) {
            SetiAstroDenoiseParameters.setiAstroDenoiseParentFolderPath = pathDialog.directory;
            SetiAstroDenoiseParameters.save();
        }
    };

    this.okButton = new PushButton(this);
    this.okButton.text = "OK";
    this.okButton.onClick = () => this.ok();

    this.cancelButton = new PushButton(this);
    this.cancelButton.text = "Cancel";
    this.cancelButton.onClick = () => this.cancel();

    // New Instance button
    this.newInstanceButton = new ToolButton(this);
    this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
    this.newInstanceButton.setScaledFixedSize(24, 24);
    this.newInstanceButton.toolTip = "Save a new instance of this script";
    this.newInstanceButton.onMousePress = function() {
        this.dialog.newInstance();
    }.bind(this);

    this.buttonsSizer = new HorizontalSizer;
    this.buttonsSizer.spacing = 6;
    this.buttonsSizer.add(this.newInstanceButton);
    this.buttonsSizer.addStretch();
    this.buttonsSizer.add(this.okButton);
    this.buttonsSizer.add(this.cancelButton);
    this.buttonsSizer.addStretch();

    // Layout
    this.sizer = new VerticalSizer;
    this.sizer.margin = 6;
    this.sizer.spacing = 6;
    this.sizer.addStretch();
    this.sizer.add(this.title);
    this.sizer.add(this.description);
    this.sizer.addStretch();
    this.sizer.add(this.imageSelectionSizer);
    this.sizer.spacing = 6;
    this.sizer.add(this.denoiseStrengthSlider);
        this.sizer.add(this.denoiseModeSizer);
        this.sizer.addStretch();

    // GPU Acceleration checkbox (only for Windows)

        this.gpuAccelerationCheckbox = new CheckBox(this);
        this.gpuAccelerationCheckbox.text = "Enable GPU Acceleration";
        this.gpuAccelerationCheckbox.checked = true;  // Default to enabled
        this.gpuAccelerationCheckbox.onCheck = function(checked) {
            SetiAstroDenoiseParameters.useGPU = checked;
        };
        this.sizer.add(this.gpuAccelerationCheckbox);


    this.sizer.add(this.setupButton);
    this.sizer.addSpacing(12);
    this.sizer.add(this.buttonsSizer);

    this.windowTitle = "SetiAstroCosmicClarity Script";
    this.adjustToContents();


}
SetiAstroDenoiseDialog.prototype = new Dialog;

function saveImageAsTiff(inputFolderPath, view) {
    // Obtain the ImageWindow object from the view's main window
    let imgWindow = view.isMainView ? view.window : view.mainView.window;

    if (!imgWindow) {
        throw new Error("Image window is undefined for the specified view.");
    }

    let fileName = imgWindow.mainView.id;  // Get the main view's id as the filename
    let filePath = inputFolderPath + pathSeparator + fileName + ".xisf";


    // Save the image in XISF format
    if (!imgWindow.saveAs(filePath, false, false, false, false)) {
        throw new Error("Failed to save image as 32-bit XISF: " + filePath);
    }

    console.writeln("Image saved as 32-bit XISF: " + filePath);
    return filePath;
}


// Create batch file to run the denoise process
function createBatchFile(batchFilePath, exePath, denoiseStrength, useGPU, denoiseMode) {
    let batchContent;

// macOS/Linux shell script
if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS") {
    batchContent = "#!/bin/sh\n";
    batchContent += "cd \"" + exePath + "\"\n";
    batchContent += 'osascript -e \'tell application "Terminal" to do script "' +
                    exePath + "/setiastrocosmicclarity_denoisemac " +  // Use the full path to the executable
                    '--denoise_strength ' + denoiseStrength.toFixed(2) + " " +
                    '--denoise_mode ' + SetiAstroDenoiseParameters.denoiseMode + " " +  // Add the denoise mode to the command
                    (useGPU ? "" : "--disable_gpu") + "\"\'\n";  // Correct the quote placement
    } // Linux shell script
else if (CoreApplication.platform == "Linux") {
    batchContent = "#!/bin/sh\n";
    batchContent += "cd \"" + exePath + "\"\n";
    batchContent += "gnome-terminal -- bash -c '" +
                    "./SetiAstroCosmicClarity_denoise " +  // Use the Linux executable
                    '--denoise_strength ' + denoiseStrength.toFixed(2) + " " +
                    '--denoise_mode ' + SetiAstroDenoiseParameters.denoiseMode + " " +
                    (useGPU ? '' : '--disable_gpu') + "; exec bash'";  // Add exec bash to keep terminal open
}
    // Windows script
    else if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
        batchContent = "@echo off\n";
        batchContent += "cd /d \"" + exePath + "\"\n";
        batchContent += "start setiastrocosmicclarity_denoise.exe " +
                        "--denoise_strength " + denoiseStrength.toFixed(2) + " " +
                        "--denoise_mode " + SetiAstroDenoiseParameters.denoiseMode + " " +
                        (useGPU ? "" : "--disable_gpu") + "\n";
    } else {
        console.criticalln("Unsupported platform: " + CoreApplication.platform);
        return false;
    }

    // Write the script to the specified path
    try {
        File.writeTextFile(batchFilePath, batchContent);
        console.writeln((CoreApplication.platform == "Linux") ?
                        "Shell script created: " + batchFilePath :
                        "Batch file created: " + batchFilePath);
    } catch (error) {
        console.criticalln("Failed to create batch/shell file: " + error.message);
        return false;
    }

    return true;
}


// Function to wait for the output file indefinitely
function waitForFile(outputFilePath) {
    let pollingInterval = 1000;  // Poll every 1 second
    let postFindDelay = 2000;    // Delay of 2 seconds after finding the file

    // Keep looping until the file exists
    while (!File.exists(outputFilePath)) {
        msleep(pollingInterval);
    }

    console.writeln("Output file found: " + outputFilePath);
    console.writeln("Waiting for " + (postFindDelay / 1000) + " seconds to ensure the file is completely saved.");
    msleep(postFindDelay);

    return true;
}




// Process the denoised image after waiting for it
function processOutputImage(outputFilePath, targetView) {
    if (!File.exists(outputFilePath)) {
        console.criticalln("Denoised file not found: " + outputFilePath);
        return;
    }

    let denoisedWindow = ImageWindow.open(outputFilePath)[0];
    if (denoisedWindow) {
        denoisedWindow.show();

        // Now apply PixelMath to replace the original image with the reverted, denoised image
        let pixelMath = new PixelMath;
        pixelMath.expression = "iif(" + denoisedWindow.mainView.id + " == 0, $T, " + denoisedWindow.mainView.id + ")";
        pixelMath.useSingleExpression = true;
        pixelMath.createNewImage = false;
        pixelMath.executeOn(targetView.mainView);  // Replace the target view (main image) with the denoised one

        // Close the denoised image window after PixelMath operation
        denoisedWindow.forceClose();

        // Try deleting the temporary denoised file
        try {
            File.remove(outputFilePath);
            console.writeln("Deleted denoised file: " + outputFilePath);
        } catch (error) {
            console.warningln("Failed to delete denoised file: " + outputFilePath);
        }
    } else {
        console.criticalln("Failed to open denoised image: " + outputFilePath);
    }
}



// Function to delete the input file
function deleteInputFile(inputFilePath) {
    try {
        if (File.exists(inputFilePath)) {
            File.remove(inputFilePath);
            console.writeln("Deleted input file: " + inputFilePath);
        } else {
            console.warningln("Input file not found: " + inputFilePath);
        }
    } catch (error) {
        console.warningln("Failed to delete input file: " + inputFilePath);
    }
}

function createCmd(
    exePath,              // Folder containing the executable
    denoiseStrength,
    useGPU,
    denoiseMode
) {
    // Validate numeric parameters
    denoiseStrength = parseFloat(denoiseStrength);
    if (isNaN(denoiseStrength)) denoiseStrength = 0.9; // Default value

    // Initialize command line
    let cmdLine = "";

    if (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") {
        // Full path to the Windows executable
        let exeFullPath = exePath + "/" + "setiastrocosmicclarity_denoise.exe";

        // Construct the command line with the executable path in quotes
        cmdLine =
            "\"" + exeFullPath + "\" " +
            "--denoise_strength " + denoiseStrength.toFixed(2) + " " +
            "--denoise_mode \"" + denoiseMode + "\" " +
            (useGPU ? "" : "--disable_gpu");
    }
    else if (CoreApplication.platform == "MACOSX" || CoreApplication.platform == "macOS") {
        // Full path to the macOS executable
        let exeFullPath = exePath + "/" + "setiastrocosmicclarity_denoisemac";

        // Construct the command line with the executable path in quotes
        cmdLine =
            "\"" + exeFullPath + "\" " +
            "--denoise_strength " + denoiseStrength.toFixed(2) + " " +
            "--denoise_mode \"" + denoiseMode + "\" " +
            (useGPU ? "" : "--disable_gpu");
    }
    else if (CoreApplication.platform == "Linux") {
        // Full path to the Linux executable
        let exeFullPath = exePath + "/" + "SetiAstroCosmicClarity_denoise";

        // Construct the command line with the executable path in quotes
        cmdLine =
            "\"" + exeFullPath + "\" " +
            "--denoise_strength " + denoiseStrength.toFixed(2) + " " +
            "--denoise_mode \"" + denoiseMode + "\" " +
            (useGPU ? "" : "--disable_gpu");
    }
    else {
        console.criticalln("Unsupported platform: " + CoreApplication.platform);
        return false;
    }

    return cmdLine;
}


// Main execution block for running the script
let dialog = new SetiAstroDenoiseDialog();
console.show();
console.writeln("SetiAstroCosmicClarityDenoise process started.");
console.flush();

if (dialog.execute()) {
    let selectedIndex = dialog.imageSelectionDropdown.currentItem;
    let selectedView = ImageWindow.windows[selectedIndex];

    if (!selectedView) {
        console.criticalln("Please select an image.");
    } else {
        let inputFolderPath = SetiAstroDenoiseParameters.setiAstroDenoiseParentFolderPath + pathSeparator + "input";
        let outputFolderPath = SetiAstroDenoiseParameters.setiAstroDenoiseParentFolderPath + pathSeparator + "output";
        let outputFileName = selectedView.mainView.id + "_denoised.xisf";
        let outputFilePath = outputFolderPath + pathSeparator + outputFileName;

        let inputFilePath = saveImageAsTiff(inputFolderPath, selectedView);
        let cmdLine = createCmd(
            SetiAstroDenoiseParameters.setiAstroDenoiseParentFolderPath,
            SetiAstroDenoiseParameters.denoiseStrength,
            SetiAstroDenoiseParameters.useGPU,
            SetiAstroDenoiseParameters.denoiseMode
        );


        let process = new ExternalProcess;
        let p = false;

        let message = "Progress:   0% Chunks:   0/  0";

        // Set up callbacks (unchanged)
        process.onStandardOutputDataAvailable = function() {
            var output = String(this.stdout);
            if (output.contains("processed")) {
                output = "INFO -> " + output.trim();
            }
            let match = output.match(/Progress:\s([\d.]+)%\s\((\d+)\/(\d+)\s/);
            if (match) {
                let percentage = parseFloat(match[1]);
                let processedChunks = parseInt(match[2], 10);
                let totalChunks = parseInt(match[3], 10);

                if (!p) {
                    Console.writeln('<end><cbr><be>' + message);
                    p = true;
                } else {
                    Console.write(format(
                        "<end>" + "\b".repeat(message.length - 7) +
                        "%3d%% Chunks:%5d/%5d", percentage, processedChunks, totalChunks
                    ));
                }
            } else {
                Console.writeln(output);
            }
        };
        process.onStandardErrorDataAvailable = function() {
            Console.criticalln('Error: ' + this.stderr.toString());
        };
        process.onStarted = function() {
            Console.noteln("starting CC..." + CMD_EXEC + " " + cmdLine);
        };
        process.onError = function(code) {
            Console.criticalln(' ERROR: ' + code);
        };
        process.onFinished = function() {
            Console.noteln('CC finished...');
        };

        try {
            // === Tokenize the command line ===
            // cmdLine is something like:
            // "C:/Users/Gaming/Desktop/Python Code/dist/CosmicClaritySuite_Windows/setiastrocosmicclarity_denoise.exe" --denoise_strength 0.90 --denoise_mode "full"

            // Tokenize using regex to preserve quoted substrings
            let tokens = cmdLine.match(/"[^"]+"|\S+/g);
            if (!tokens || tokens.length < 1) {
                console.criticalln("Could not parse command line: " + cmdLine);
                throw new Error("No tokens found");
            }

            // Extract executable path and arguments
            let exePath = tokens[0].replace(/^"(.*)"$/, "$1"); // Remove surrounding quotes
            let args = [];
            for (let i = 1; i < tokens.length; i++) {
                args.push(tokens[i].replace(/^"(.*)"$/, "$1")); // Remove quotes from args
            }


            // Start the process
            if (!process.start(exePath, args)) {
                console.noteln("SetiAstroCosmicClarityDenoise starting...");
                console.flush();
            }

            // The existing blocking loops
            for (; process.isStarting; )
                processEvents();
            for (; process.isRunning; )
                processEvents();

        } catch (error) {
            console.criticalln("Error starting process: " + error.message);
        }

        // Wait for the output file and process it
        if (waitForFile(outputFilePath)) {
            processOutputImage(outputFilePath, selectedView);
            deleteInputFile(inputFilePath);
        } else {
            console.criticalln("Output file not found within timeout.");
        }
    }
}
